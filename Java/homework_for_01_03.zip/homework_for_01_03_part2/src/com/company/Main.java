package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        //2. Implement the program that ask user to input three integers (use Scanner), and print the maximum of three numbers.
        //19,10,1 ->19
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int num3 = sc.nextInt();
        if (num1 > num2)
            if (num1 > num3)
                System.out.println("The greatest: " + num1);

        if (num2 > num1)
            if (num2 > num3)
                System.out.println("The greatest: " + num2);

        if (num3 > num1)
            if (num3 > num2)
                System.out.println("The greatest: " + num3);
    }
}
